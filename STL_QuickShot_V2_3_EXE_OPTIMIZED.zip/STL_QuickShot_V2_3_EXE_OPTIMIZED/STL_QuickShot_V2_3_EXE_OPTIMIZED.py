# -*- coding: utf-8 -*-
"""
STL QuickShot V2.3 SHARP LOGO

Bản sửa lỗi văng app:
- Bỏ PySide6 + pyvistaqt preview trực tiếp vì một số máy Windows bị crash do VTK/Qt.
- Dùng Tkinter + PyVista off-screen giống bản V1 nên ổn định hơn.

Tính năng:
- Open 1 STL hoặc Open STL Parts chọn nhiều STL cùng lúc.
- Giữ nguyên tọa độ gốc / vị trí tương đối của nhiều part.
- Preview nhanh bằng ảnh render off-screen.
- Nút xoay trái / phải / lên / xuống / nghiêng ngang.
- 2 logo cùng lúc, kéo thả trực tiếp trên preview.
- Xuất 8 PNG.
- Xuất GIF 720x720, tối ưu dưới giới hạn MB.
- Xuất MP4 720x720 nếu có imageio + imageio-ffmpeg.
- Thêm nền studio sáng giữa, nền trong suốt PNG và xoay mượt chậm-nhanh-chậm.
"""

from __future__ import annotations

import math
import os
import re
import sys
import tempfile
import traceback
import gc
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image, ImageTk, ImageFilter
except Exception as exc:
    print("Thiếu Pillow. Hãy chạy INSTALL_LIBS.bat")
    print(exc)
    input("Nhấn Enter để thoát...")
    sys.exit(1)

APP_NAME = "STL QuickShot V2.3 EXE OPTIMIZED"
CANVAS_SIZE = 680
GIF_SIZE = 720
VIEW_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315]
VIEW_NAMES = [
    "front",
    "front_right",
    "right",
    "back_right",
    "back",
    "back_left",
    "left",
    "front_left",
]

# Xuất nhanh theo yêu cầu: Front / Back / Left / Right
VIEW4_ANGLES = [0, 180, 270, 90]
VIEW4_NAMES = ["front", "back", "left", "right"]
FRONT_ANGLE = 0
FRONT_NAME = "front"

BG_COLORS = {
    "Trắng": "white",
    "Xám sáng": "#d8d8d8",
    "Xám tối": "#303030",
    "Đen": "black",
    "Studio sáng giữa": "#f1f1ee",
    "Studio tối viền": "#1f1f22",
    "Trong suốt": "transparent",
}

STUDIO_BG_MODES = {"Studio sáng giữa", "Studio tối viền"}
TRANSPARENT_BG_MODE = "Trong suốt"

MODEL_COLORS = {
    "Clay xám": "#b8b6ad",
    "Resin trắng": "#eeeeee",
    "Xám đậm": "#777777",
    "Đen mờ": "#222222",
    "Vàng nhạt": "#dcc26c",
}


@dataclass
class RenderSettings:
    image_size: int = 1600
    background_mode: str = "Trắng"
    background_color: str = "white"
    transparent_background: bool = False
    studio_background: bool = False
    model_color: str = "#b8b6ad"
    orthographic: bool = True
    zoom: float = 1.18
    camera_height_ratio: float = 0.28
    smooth: bool = True
    supersample: int = 2
    sharpen: bool = True


class LogoState:
    def __init__(self, index: int):
        self.index = index
        self.enabled: bool = False
        self.path: str = ""
        self.pil: Optional[Image.Image] = None
        self.tk_img: Optional[ImageTk.PhotoImage] = None
        self.canvas_item: Optional[int] = None
        self.norm_x: float = 0.76 if index == 1 else 0.04
        self.norm_y: float = 0.84
        self.scale_percent: float = 18.0
        self.opacity_percent: float = 100.0

    def clear(self):
        self.enabled = False
        self.path = ""
        self.pil = None
        self.tk_img = None
        self.canvas_item = None
        self.norm_x = 0.76 if self.index == 1 else 0.04
        self.norm_y = 0.84


def safe_filename(name: str) -> str:
    name = re.sub(r"[^a-zA-Z0-9_\-]+", "_", name.strip())
    name = name.strip("_")
    return name or "model"


def ensure_dir(path: str) -> None:
    Path(path).mkdir(parents=True, exist_ok=True)


def write_crash_log(text: str):
    try:
        p = Path(__file__).resolve().parent / "crash_log.txt"
        p.write_text(text, encoding="utf-8")
    except Exception:
        pass


def import_pyvista():
    try:
        import pyvista as pv
    except Exception as exc:
        raise RuntimeError(
            "Chưa cài thư viện pyvista/vtk. Hãy chạy INSTALL_LIBS.bat hoặc cài lại thư viện.\n"
            "Lệnh: python -m pip install -r requirements.txt"
        ) from exc

    try:
        pv.OFF_SCREEN = True
        pv.global_theme.window_size = [1000, 1000]
        pv.global_theme.smooth_shading = True
    except Exception:
        pass
    return pv


def mesh_stats(mesh) -> Tuple[Tuple[float, float, float], float, float, float, float]:
    bounds = mesh.bounds
    center = mesh.center
    dx = float(bounds[1] - bounds[0])
    dy = float(bounds[3] - bounds[2])
    dz = float(bounds[5] - bounds[4])
    max_dim = max(dx, dy, dz, 1e-6)
    return center, dx, dy, dz, max_dim


def load_single_mesh(pv, path: str):
    mesh = pv.read(path)
    if mesh.__class__.__name__.lower().endswith("multiblock"):
        mesh = mesh.combine()
    if hasattr(mesh, "extract_surface"):
        mesh = mesh.extract_surface()
    if hasattr(mesh, "triangulate"):
        try:
            mesh = mesh.triangulate()
        except Exception:
            pass
    if not hasattr(mesh, "n_points") or int(mesh.n_points) <= 0:
        raise ValueError("File STL không có điểm/mesh hợp lệ.")
    try:
        mesh = mesh.compute_normals(
            point_normals=True,
            cell_normals=True,
            auto_orient_normals=True,
            consistent_normals=True,
            inplace=False,
        )
    except Exception:
        pass
    return mesh


def combine_meshes_keep_coords(pv, meshes: List[Any]):
    if len(meshes) == 1:
        return meshes[0]
    # Không center từng part. Gộp trực tiếp để giữ nguyên tọa độ gốc.
    try:
        return pv.MultiBlock(meshes).combine(merge_points=False).extract_surface()
    except TypeError:
        return pv.MultiBlock(meshes).combine().extract_surface()
    except Exception:
        combined = meshes[0].copy(deep=True)
        for m in meshes[1:]:
            try:
                combined = combined.merge(m, merge_points=False)
            except TypeError:
                combined = combined.merge(m)
        try:
            combined = combined.extract_surface()
        except Exception:
            pass
        return combined


def rotate_mesh(mesh, rot_x: float, rot_y: float, rot_z: float):
    if mesh is None:
        return None
    out = mesh.copy(deep=True)
    point = mesh.center
    try:
        if abs(rot_x) > 1e-6:
            out.rotate_x(rot_x, point=point, inplace=True)
        if abs(rot_y) > 1e-6:
            out.rotate_y(rot_y, point=point, inplace=True)
        if abs(rot_z) > 1e-6:
            out.rotate_z(rot_z, point=point, inplace=True)
        return out
    except Exception:
        # PyVista cũ hơn có khác chữ ký hàm.
        if abs(rot_x) > 1e-6:
            out = out.rotate_x(rot_x, point=point, inplace=False)
        if abs(rot_y) > 1e-6:
            out = out.rotate_y(rot_y, point=point, inplace=False)
        if abs(rot_z) > 1e-6:
            out = out.rotate_z(rot_z, point=point, inplace=False)
        return out




def ease_in_out_sine(t: float) -> float:
    """0..1 -> 0..1, chậm ở đầu/cuối, nhanh ở giữa."""
    t = max(0.0, min(1.0, float(t)))
    return 0.5 - 0.5 * math.cos(math.pi * t)


def turntable_angles(frame_count: int, eased: bool = True) -> List[float]:
    frame_count = max(2, int(frame_count))
    if eased:
        # Có cả frame 0° và 360° để vòng lặp GIF/MP4 mượt khi quay lại đầu.
        return [360.0 * ease_in_out_sine(i / max(1, frame_count - 1)) for i in range(frame_count)]
    return [360.0 * i / frame_count for i in range(frame_count)]


def make_studio_background(size: int, mode: str) -> Image.Image:
    """Tạo phông studio 2D: sáng ở giữa, tối nhẹ xung quanh."""
    size = int(size)
    if mode == "Studio tối viền":
        center = (120, 120, 122)
        edge = (25, 25, 28)
        floor = (48, 48, 52)
    else:
        center = (246, 246, 242)
        edge = (170, 170, 168)
        floor = (204, 204, 198)

    cx = size * 0.50
    cy = size * 0.43
    max_r = math.sqrt(cx * cx + cy * cy)
    img = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    px = img.load()
    for y in range(size):
        # Nền studio có cảm giác sàn nhẹ ở phần dưới.
        floor_mix = max(0.0, (y - size * 0.58) / (size * 0.42))
        for x in range(size):
            d = math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / max_r
            d = max(0.0, min(1.0, d))
            # Smoothstep vignette.
            v = d * d * (3 - 2 * d)
            r = int(center[0] * (1 - v) + edge[0] * v)
            g = int(center[1] * (1 - v) + edge[1] * v)
            b = int(center[2] * (1 - v) + edge[2] * v)
            if floor_mix > 0:
                fm = min(0.45, floor_mix * 0.45)
                r = int(r * (1 - fm) + floor[0] * fm)
                g = int(g * (1 - fm) + floor[1] * fm)
                b = int(b * (1 - fm) + floor[2] * fm)
            px[x, y] = (r, g, b, 255)
    return img


def composite_on_background(foreground: Image.Image, background: Image.Image) -> Image.Image:
    bg = background.convert("RGBA")
    fg = foreground.convert("RGBA")
    bg.alpha_composite(fg)
    return bg


def flatten_rgba(image: Image.Image, bg=(255, 255, 255)) -> Image.Image:
    """MP4/GIF tối ưu bằng RGB, nên cần trải nền nếu ảnh đang trong suốt."""
    if image.mode != "RGBA":
        return image.convert("RGB")
    base = Image.new("RGBA", image.size, (bg[0], bg[1], bg[2], 255))
    base.alpha_composite(image)
    return base.convert("RGB")

def add_lighting(plotter, pv, mesh, studio: bool = False):
    try:
        plotter.remove_all_lights()
    except Exception:
        pass

    center, _dx, _dy, _dz, max_dim = mesh_stats(mesh)

    if studio:
        # Ánh sáng studio: key light mạnh ở chính giữa/trên trước, thêm fill và rim nhẹ.
        lights = [
            (center[0], center[1] - max_dim * 2.8, center[2] + max_dim * 2.8, 1.25),
            (center[0] - max_dim * 2.0, center[1] - max_dim * 1.8, center[2] + max_dim * 1.5, 0.42),
            (center[0] + max_dim * 2.0, center[1] + max_dim * 2.0, center[2] + max_dim * 1.4, 0.36),
            (center[0], center[1] + max_dim * 2.3, center[2] + max_dim * 0.5, 0.22),
        ]
    else:
        lights = [
            (center[0] - max_dim * 2.2, center[1] - max_dim * 2.4, center[2] + max_dim * 2.6, 0.95),
            (center[0] + max_dim * 2.4, center[1] + max_dim * 1.8, center[2] + max_dim * 1.7, 0.45),
            (center[0], center[1] - max_dim * 2.0, center[2] + max_dim * 0.45, 0.30),
        ]

    for x, y, z, intensity in lights:
        try:
            light = pv.Light(position=(x, y, z), focal_point=center, color="white", intensity=float(intensity))
            plotter.add_light(light)
        except Exception:
            pass
    try:
        if len(plotter.renderer.lights) == 0:
            plotter.enable_lightkit()
    except Exception:
        pass

def apply_camera(plotter, mesh, angle_deg: float, settings: RenderSettings):
    center, _dx, _dy, _dz, max_dim = mesh_stats(mesh)
    rad = math.radians(angle_deg)
    distance = max_dim * 3.2
    cam_x = center[0] + math.sin(rad) * distance
    cam_y = center[1] - math.cos(rad) * distance
    cam_z = center[2] + max_dim * float(settings.camera_height_ratio)
    plotter.camera_position = [(cam_x, cam_y, cam_z), center, (0, 0, 1)]

    try:
        plotter.camera.parallel_projection = bool(settings.orthographic)
    except Exception:
        pass

    if settings.orthographic:
        zoom = max(float(settings.zoom), 0.2)
        try:
            plotter.camera.parallel_scale = max_dim * 0.66 / zoom
        except Exception:
            pass
    else:
        try:
            plotter.camera.view_angle = 28
            plotter.camera.zoom(max(float(settings.zoom), 0.2))
        except Exception:
            pass
    try:
        plotter.reset_camera_clipping_range()
    except Exception:
        pass


def render_mesh_to_pil(
    pv,
    mesh,
    settings: RenderSettings,
    angle_deg: float,
    size: int,
) -> Image.Image:
    plotter = pv.Plotter(
        off_screen=True,
        window_size=(int(size), int(size)),
        lighting="none",
        border=False,
    )
    try:
        # Studio và Trong suốt cần alpha thật để hậu kỳ nền / giữ RGBA.
        use_alpha = bool(settings.transparent_background or settings.studio_background)
        bg_color = "white" if use_alpha else settings.background_color
        plotter.set_background(bg_color)
        add_lighting(plotter, pv, mesh, studio=bool(settings.studio_background))
        try:
            plotter.enable_anti_aliasing("ssaa")
        except Exception:
            try:
                plotter.enable_anti_aliasing()
            except Exception:
                pass
        try:
            plotter.enable_eye_dome_lighting()
        except Exception:
            pass
        ambient = 0.36 if settings.studio_background else 0.32
        diffuse = 0.84 if settings.studio_background else 0.78
        specular = 0.28 if settings.studio_background else 0.22
        plotter.add_mesh(
            mesh,
            color=settings.model_color,
            smooth_shading=bool(settings.smooth),
            ambient=ambient,
            diffuse=diffuse,
            specular=specular,
            specular_power=32,
        )
        apply_camera(plotter, mesh, angle_deg, settings)
        plotter.render()
        arr = plotter.screenshot(return_img=True, transparent_background=use_alpha)
        if arr is None:
            raise RuntimeError("Render không trả ảnh.")
        img = Image.fromarray(arr)
        if img.mode != "RGBA":
            img = img.convert("RGBA")

        if settings.studio_background:
            bg = make_studio_background(int(size), settings.background_mode)
            img = composite_on_background(img, bg)
        elif not settings.transparent_background:
            # Đảm bảo ảnh nền thường luôn opaque, tránh cạnh alpha lạ khi lưu/xuất video.
            base = Image.new("RGBA", img.size, settings.background_color)
            base.alpha_composite(img)
            img = base
        return img
    finally:
        try:
            plotter.close()
        except Exception:
            pass
        try:
            gc.collect()
        except Exception:
            pass


def sharpen_rgba(image: Image.Image, percent: int = 135) -> Image.Image:
    """Tăng nét nhẹ nhưng giữ alpha, giúp chi tiết STL và logo không bị mềm."""
    if image.mode != "RGBA":
        image = image.convert("RGBA")
    alpha = image.getchannel("A")
    rgb = image.convert("RGB")
    rgb = rgb.filter(ImageFilter.UnsharpMask(radius=0.8, percent=int(percent), threshold=2))
    out = rgb.convert("RGBA")
    out.putalpha(alpha)
    return out


def render_mesh_high_quality(
    pv,
    mesh,
    settings: RenderSettings,
    angle_deg: float,
    final_size: int,
    preview: bool = False,
) -> Image.Image:
    """Render oversampling rồi downsample để ảnh sắc hơn, hạn chế răng cưa."""
    final_size = int(final_size)
    ss = max(1, min(3, int(getattr(settings, "supersample", 1))))
    if preview:
        ss = min(ss, 2)
    render_size = final_size * ss
    # Tránh render quá lớn gây nặng máy hoặc văng VTK.
    if render_size > 4096:
        render_size = 4096
    img = render_mesh_to_pil(pv, mesh, settings, angle_deg=angle_deg, size=render_size)
    if render_size != final_size:
        img = img.resize((final_size, final_size), Image.Resampling.LANCZOS)
    if getattr(settings, "sharpen", True):
        img = sharpen_rgba(img, percent=145 if not preview else 120)
    return img


class STLQuickShotApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1320x840")
        self.minsize(1120, 720)

        self.pv = None
        self.original_mesh = None
        self.stl_paths: List[str] = []
        self.rot_x = 0.0
        self.rot_y = 0.0
        self.rot_z = 0.0
        self.preview_base_pil: Optional[Image.Image] = None
        self.preview_tk: Optional[ImageTk.PhotoImage] = None
        self.logo1 = LogoState(1)
        self.logo2 = LogoState(2)
        self.drag_logo: Optional[LogoState] = None
        self.selected_logo: Optional[LogoState] = None
        self.drag_offset = (0, 0)
        self._updating_logo_vars = False
        self.is_busy = False
        self.preview_pending = False
        self.preview_after_id = None
        self._last_preview_key = None
        self.action_buttons: List[ttk.Button] = []

        self.var_bg = tk.StringVar(value="Studio tối viền")
        self.var_color = tk.StringVar(value="Xám đậm")
        self.var_png_size = tk.IntVar(value=1600)
        self.var_zoom = tk.DoubleVar(value=1.18)
        self.var_height = tk.DoubleVar(value=0.28)
        self.var_ortho = tk.BooleanVar(value=True)
        self.var_smooth = tk.BooleanVar(value=True)
        self.var_supersample = tk.IntVar(value=3)
        self.var_sharpen = tk.BooleanVar(value=True)
        self.var_step = tk.IntVar(value=15)
        self.var_output = tk.StringVar(value="")
        self.var_gif_frames = tk.IntVar(value=48)
        self.var_gif_fps = tk.IntVar(value=12)
        self.var_gif_limit = tk.DoubleVar(value=10.0)
        self.var_mp4_seconds = tk.IntVar(value=5)
        self.var_mp4_fps = tk.IntVar(value=24)
        self.var_ease_rotate = tk.BooleanVar(value=True)

        self.logo_vars: Dict[int, Dict[str, tk.Variable]] = {}

        self.build_ui()
        self.log("STL QuickShot V2.3 EXE OPTIMIZED đã sẵn sàng. Đã set mặc định theo ảnh mẫu.")
        self.log("Bản tối ưu: thêm xuất 1 ảnh Front, 4 ảnh Front/Back/Left/Right, chống bấm chồng tác vụ và giảm treo khi mở model mới.")
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- UI ----------------
    def build_ui(self):
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True, padx=8, pady=8)

        left = ttk.Frame(root)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(root, width=430)
        right.pack(side="right", fill="y", padx=(10, 0))

        self.canvas = tk.Canvas(left, width=CANVAS_SIZE, height=CANVAS_SIZE, bg="#202020", highlightthickness=1, highlightbackground="#555")
        self.canvas.pack(anchor="center", pady=(0, 0))
        self.canvas.create_text(
            CANVAS_SIZE // 2,
            CANVAS_SIZE // 2,
            text="OPEN STL / OPEN STL PARTS",
            fill="#dddddd",
            font=("Segoe UI", 18, "bold"),
        )
        # Bind toàn canvas, không bind theo item. Cách này kéo logo ổn định hơn vì khi kéo ta redraw canvas.
        self.canvas.bind("<ButtonPress-1>", self.on_logo_press)
        self.canvas.bind("<B1-Motion>", self.on_logo_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_logo_release)

        self.lbl_status = ttk.Label(left, text="Sẵn sàng", anchor="w")
        self.lbl_status.pack(fill="x", pady=(6, 0))

        self.progress = ttk.Progressbar(left, mode="indeterminate")
        self.progress.pack(fill="x", pady=(4, 0))

        self.txt_log = tk.Text(left, height=7, wrap="word")
        self.txt_log.pack(fill="both", expand=True, pady=(6, 0))

        self.nb = ttk.Notebook(right)
        self.nb.pack(fill="both", expand=True)
        tab_main = ttk.Frame(self.nb)
        tab_logo = ttk.Frame(self.nb)
        tab_out = ttk.Frame(self.nb)
        self.nb.add(tab_main, text="Model")
        self.nb.add(tab_logo, text="Logo")
        self.nb.add(tab_out, text="Xuất")

        self.build_model_tab(tab_main)
        self.build_logo_tab(tab_logo)
        self.build_output_tab(tab_out)

    def build_model_tab(self, parent):
        frm = ttk.Frame(parent, padding=8)
        frm.pack(fill="both", expand=True)

        row = ttk.Frame(frm)
        row.pack(fill="x")
        self.btn_open_one = ttk.Button(row, text="Open 1 STL", command=self.open_one_stl)
        self.btn_open_one.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_open_parts = ttk.Button(row, text="Open STL Parts", command=self.open_stl_parts)
        self.btn_open_parts.pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.btn_clear_scene = ttk.Button(frm, text="Clear Scene", command=self.clear_scene)
        self.btn_clear_scene.pack(fill="x", pady=(6, 8))
        self.action_buttons.extend([self.btn_open_one, self.btn_open_parts, self.btn_clear_scene])

        ttk.Label(frm, text="Chế độ ghép: GIỮ NGUYÊN TỌA ĐỘ GỐC", foreground="#087a08", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.list_parts = tk.Listbox(frm, height=8)
        self.list_parts.pack(fill="x", pady=(4, 10))

        orient = ttk.LabelFrame(frm, text="Chỉnh hướng model")
        orient.pack(fill="x", pady=(4, 8))
        row_step = ttk.Frame(orient)
        row_step.pack(fill="x", padx=6, pady=6)
        ttk.Label(row_step, text="Bước xoay:").pack(side="left")
        ttk.Spinbox(row_step, from_=1, to=90, textvariable=self.var_step, width=7).pack(side="left", padx=6)
        ttk.Label(row_step, text="độ").pack(side="left")

        grid = ttk.Frame(orient)
        grid.pack(padx=6, pady=(0, 6))
        ttk.Button(grid, text="Xoay lên", command=lambda: self.rotate_model(x=self.var_step.get())).grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Xoay trái", command=lambda: self.rotate_model(z=self.var_step.get())).grid(row=1, column=0, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Xoay phải", command=lambda: self.rotate_model(z=-self.var_step.get())).grid(row=1, column=2, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Xoay xuống", command=lambda: self.rotate_model(x=-self.var_step.get())).grid(row=2, column=1, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Nghiêng trái", command=lambda: self.rotate_model(y=self.var_step.get())).grid(row=3, column=0, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Nghiêng phải", command=lambda: self.rotate_model(y=-self.var_step.get())).grid(row=3, column=2, padx=3, pady=3, sticky="ew")
        ttk.Button(grid, text="Reset góc", command=self.reset_rotation).grid(row=4, column=0, columnspan=3, padx=3, pady=3, sticky="ew")
        for c in range(3):
            grid.columnconfigure(c, weight=1)
        self.lbl_rot = ttk.Label(orient, text="X=0°, Y=0°, Z=0°")
        self.lbl_rot.pack(anchor="w", padx=6, pady=(0, 6))

        render = ttk.LabelFrame(frm, text="Render")
        render.pack(fill="x", pady=(4, 8))
        self.add_combo(render, "Nền:", self.var_bg, list(BG_COLORS.keys()), self.update_preview_safe)
        ttk.Label(
            render,
            text="Studio sáng giữa = phông studio/vignette. Trong suốt = PNG RGBA không nền.",
            wraplength=360,
            foreground="#666666",
        ).pack(anchor="w", padx=6, pady=(0, 4))
        self.add_combo(render, "Màu model:", self.var_color, list(MODEL_COLORS.keys()), self.update_preview_safe)
        self.add_spin(render, "Kích thước PNG:", self.var_png_size, 512, 4096, self.update_preview_safe, suffix="px")
        self.add_float_spin(render, "Zoom:", self.var_zoom, 0.5, 3.0, 0.05, self.update_preview_safe)
        self.add_float_spin(render, "Độ cao camera:", self.var_height, -1.0, 2.0, 0.05, self.update_preview_safe)
        ttk.Checkbutton(render, text="Orthographic / không méo phối cảnh", variable=self.var_ortho, command=self.update_preview_safe).pack(anchor="w", padx=6, pady=2)
        ttk.Checkbutton(render, text="Smooth shading", variable=self.var_smooth, command=self.update_preview_safe).pack(anchor="w", padx=6, pady=2)
        self.add_spin(render, "Render sắc nét x:", self.var_supersample, 1, 3, self.update_preview_safe, suffix="lần")
        ttk.Checkbutton(render, text="Tăng nét chi tiết sau render", variable=self.var_sharpen, command=self.update_preview_safe).pack(anchor="w", padx=6, pady=2)
        ttk.Label(render, text="Mặc định theo ảnh mẫu: Studio tối viền + Xám đậm + Render sắc nét x3 + Tăng nét.", wraplength=360, foreground="#666666").pack(anchor="w", padx=6, pady=(0, 4))
        ttk.Button(render, text="Khôi phục preset mặc định theo ảnh", command=self.apply_default_render_preset).pack(fill="x", padx=6, pady=(0, 6))

    def build_logo_tab(self, parent):
        frm = ttk.Frame(parent, padding=8)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="Có thể dùng 2 logo cùng lúc. Kéo trực tiếp trên preview, hoặc dùng X/Y và nút mũi tên để căn chính xác.", wraplength=380).pack(anchor="w", pady=(0, 8))
        self.make_logo_controls(frm, self.logo1)
        self.make_logo_controls(frm, self.logo2)
        ttk.Button(frm, text="Cập nhật logo trên preview", command=self.redraw_canvas).pack(fill="x", pady=8)

    def build_output_tab(self, parent):
        frm = ttk.Frame(parent, padding=8)
        frm.pack(fill="both", expand=True)

        out = ttk.LabelFrame(frm, text="Thư mục xuất")
        out.pack(fill="x", pady=(0, 8))
        ttk.Entry(out, textvariable=self.var_output).pack(side="left", fill="x", expand=True, padx=6, pady=6)
        ttk.Button(out, text="Chọn", command=self.choose_output_dir).pack(side="right", padx=6, pady=6)

        gif = ttk.LabelFrame(frm, text="GIF 720x720")
        gif.pack(fill="x", pady=(0, 8))
        self.add_spin(gif, "Frame:", self.var_gif_frames, 8, 72, None)
        self.add_spin(gif, "FPS:", self.var_gif_fps, 4, 30, None)
        self.add_float_spin(gif, "Giới hạn MB:", self.var_gif_limit, 1.0, 50.0, 0.5, None)
        ttk.Label(gif, text="Kích thước GIF cố định: 720 x 720 px").pack(anchor="w", padx=6, pady=3)
        ttk.Checkbutton(
            gif,
            text="Xoay mượt: chậm đầu - nhanh giữa - chậm cuối",
            variable=self.var_ease_rotate,
        ).pack(anchor="w", padx=6, pady=3)
        ttk.Label(
            gif,
            text="Lưu ý: nền Trong suốt hỗ trợ tốt nhất khi xuất PNG. GIF/MP4 sẽ tự trải nền trắng để tránh lỗi alpha.",
            wraplength=380,
            foreground="#666666",
        ).pack(anchor="w", padx=6, pady=(2, 4))

        mp4 = ttk.LabelFrame(frm, text="MP4 720x720")
        mp4.pack(fill="x", pady=(0, 8))
        self.add_spin(mp4, "Giây:", self.var_mp4_seconds, 2, 20, None)
        self.add_spin(mp4, "FPS:", self.var_mp4_fps, 12, 60, None)

        ttk.Button(frm, text="Khôi phục preset xuất theo ảnh", command=self.apply_default_render_preset).pack(fill="x", pady=(4, 8))

        self.btn_export_front = ttk.Button(frm, text="XUẤT 1 PNG FRONT", command=self.export_png_front)
        self.btn_export_front.pack(fill="x", ipady=8, pady=4)

        self.btn_export_4 = ttk.Button(frm, text="XUẤT 4 PNG FRONT / BACK / LEFT / RIGHT", command=self.export_png_4)
        self.btn_export_4.pack(fill="x", ipady=8, pady=4)

        self.btn_export_8 = ttk.Button(frm, text="XUẤT 8 PNG", command=self.export_png_8)
        self.btn_export_8.pack(fill="x", ipady=8, pady=4)

        self.btn_export_gif = ttk.Button(frm, text="XUẤT GIF 720x720 < 10MB", command=self.export_gif)
        self.btn_export_gif.pack(fill="x", ipady=8, pady=4)

        self.btn_export_mp4 = ttk.Button(frm, text="XUẤT MP4 720x720", command=self.export_mp4)
        self.btn_export_mp4.pack(fill="x", ipady=8, pady=4)

        self.btn_export_png_gif = ttk.Button(frm, text="XUẤT PNG + GIF", command=self.export_png_gif)
        self.btn_export_png_gif.pack(fill="x", ipady=10, pady=(10, 4))

        self.action_buttons.extend([
            self.btn_export_front, self.btn_export_4, self.btn_export_8,
            self.btn_export_gif, self.btn_export_mp4, self.btn_export_png_gif,
        ])

    def apply_default_render_preset(self):
        """Preset mặc định theo ảnh mẫu của người dùng."""
        try:
            self.var_bg.set("Studio tối viền")
            self.var_color.set("Xám đậm")
            self.var_png_size.set(1600)
            self.var_zoom.set(1.18)
            self.var_height.set(0.28)
            self.var_ortho.set(True)
            self.var_smooth.set(True)
            self.var_supersample.set(3)
            self.var_sharpen.set(True)
            self.var_gif_frames.set(48)
            self.var_gif_fps.set(12)
            self.var_gif_limit.set(10.0)
            self.var_mp4_seconds.set(5)
            self.var_mp4_fps.set(24)
            self.var_ease_rotate.set(True)
        except Exception:
            pass
        self.update_preview_safe()

    def add_combo(self, parent, label, var, values, command=None):
        row = ttk.Frame(parent)
        row.pack(fill="x", padx=6, pady=3)
        ttk.Label(row, text=label, width=18).pack(side="left")
        cb = ttk.Combobox(row, textvariable=var, values=values, state="readonly")
        cb.pack(side="left", fill="x", expand=True)
        if command:
            cb.bind("<<ComboboxSelected>>", lambda _e: command())
        return cb

    def add_spin(self, parent, label, var, frm, to, command=None, suffix=""):
        row = ttk.Frame(parent)
        row.pack(fill="x", padx=6, pady=3)
        ttk.Label(row, text=label, width=18).pack(side="left")
        sp = ttk.Spinbox(row, from_=frm, to=to, textvariable=var, width=10, command=command)
        sp.pack(side="left")
        if suffix:
            ttk.Label(row, text=suffix).pack(side="left", padx=4)
        if command:
            sp.bind("<FocusOut>", lambda _e: command())
            sp.bind("<Return>", lambda _e: command())
        return sp

    def add_float_spin(self, parent, label, var, frm, to, inc, command=None):
        row = ttk.Frame(parent)
        row.pack(fill="x", padx=6, pady=3)
        ttk.Label(row, text=label, width=18).pack(side="left")
        sp = ttk.Spinbox(row, from_=frm, to=to, increment=inc, textvariable=var, width=10, command=command)
        sp.pack(side="left")
        if command:
            sp.bind("<FocusOut>", lambda _e: command())
            sp.bind("<Return>", lambda _e: command())
        return sp

    def make_logo_controls(self, parent, logo: LogoState):
        box = ttk.LabelFrame(parent, text=f"Logo {logo.index}")
        box.pack(fill="x", pady=(0, 10))
        vars_ = {
            "enabled": tk.BooleanVar(value=False),
            "scale": tk.IntVar(value=int(logo.scale_percent)),
            "opacity": tk.IntVar(value=int(logo.opacity_percent)),
            "x": tk.IntVar(value=int(logo.norm_x * 100)),
            "y": tk.IntVar(value=int(logo.norm_y * 100)),
        }
        self.logo_vars[logo.index] = vars_

        row = ttk.Frame(box)
        row.pack(fill="x", padx=6, pady=5)
        ttk.Checkbutton(row, text="Bật", variable=vars_["enabled"], command=lambda l=logo: self.toggle_logo(l)).pack(side="left")
        ttk.Button(row, text="Chọn PNG", command=lambda l=logo: self.choose_logo(l)).pack(side="left", padx=4)
        ttk.Button(row, text="Xóa", command=lambda l=logo: self.clear_logo(l)).pack(side="left", padx=4)
        ttk.Button(row, text="Reset vị trí", command=lambda l=logo: self.reset_logo_pos(l)).pack(side="left", padx=4)

        row2 = ttk.Frame(box)
        row2.pack(fill="x", padx=6, pady=3)
        ttk.Label(row2, text="Size %:", width=10).pack(side="left")
        sp_scale = ttk.Spinbox(row2, from_=2, to=80, textvariable=vars_["scale"], width=8, command=lambda l=logo: self.update_logo_settings(l))
        sp_scale.pack(side="left")
        ttk.Label(row2, text="Opacity:", width=10).pack(side="left", padx=(12, 0))
        sp_op = ttk.Spinbox(row2, from_=5, to=100, textvariable=vars_["opacity"], width=8, command=lambda l=logo: self.update_logo_settings(l))
        sp_op.pack(side="left")

        row3 = ttk.Frame(box)
        row3.pack(fill="x", padx=6, pady=3)
        ttk.Label(row3, text="X%:", width=5).pack(side="left")
        sp_x = ttk.Spinbox(row3, from_=0, to=100, textvariable=vars_["x"], width=7, command=lambda l=logo: self.update_logo_settings(l))
        sp_x.pack(side="left")
        ttk.Label(row3, text="Y%:", width=5).pack(side="left", padx=(10, 0))
        sp_y = ttk.Spinbox(row3, from_=0, to=100, textvariable=vars_["y"], width=7, command=lambda l=logo: self.update_logo_settings(l))
        sp_y.pack(side="left")

        row4 = ttk.Frame(box)
        row4.pack(fill="x", padx=6, pady=(2, 6))
        ttk.Button(row4, text="←", width=4, command=lambda l=logo: self.nudge_logo(l, -0.01, 0)).pack(side="left", padx=2)
        ttk.Button(row4, text="→", width=4, command=lambda l=logo: self.nudge_logo(l, 0.01, 0)).pack(side="left", padx=2)
        ttk.Button(row4, text="↑", width=4, command=lambda l=logo: self.nudge_logo(l, 0, -0.01)).pack(side="left", padx=2)
        ttk.Button(row4, text="↓", width=4, command=lambda l=logo: self.nudge_logo(l, 0, 0.01)).pack(side="left", padx=2)
        ttk.Label(row4, text="Mỗi lần = 1% khung ảnh", foreground="#666666").pack(side="left", padx=8)

        for sp in (sp_scale, sp_op, sp_x, sp_y):
            sp.bind("<FocusOut>", lambda _e, l=logo: self.update_logo_settings(l))
            sp.bind("<Return>", lambda _e, l=logo: self.update_logo_settings(l))

    # ---------------- Busy / ổn định EXE ----------------
    def on_close(self):
        if self.is_busy:
            if not messagebox.askyesno("Đang xử lý", "Phần mềm đang render/xuất file. Đóng lúc này có thể gây lỗi file đang xuất. Vẫn đóng?"):
                return
        self.destroy()

    def set_busy(self, busy: bool, message: str = ""):
        self.is_busy = bool(busy)
        state = "disabled" if self.is_busy else "normal"
        for btn in getattr(self, "action_buttons", []):
            try:
                btn.configure(state=state)
            except Exception:
                pass
        try:
            if self.is_busy:
                self.progress.start(10)
            else:
                self.progress.stop()
        except Exception:
            pass
        if message:
            self.lbl_status.config(text=message)
        self.update_idletasks()

    def begin_task(self, name: str) -> bool:
        if self.is_busy:
            messagebox.showwarning("Đang xử lý", "Phần mềm đang render/xuất file. Hãy đợi tác vụ hiện tại hoàn thành.")
            return False
        self.set_busy(True, name)
        self.log(name)
        return True

    def end_task(self, name: str = "Sẵn sàng"):
        self.set_busy(False, name)
        try:
            gc.collect()
        except Exception:
            pass

    def reset_runtime_before_new_model(self):
        """Dọn bộ nhớ/preview trước khi mở STL mới để tránh kéo dãn canvas, treo hoặc văng sau khi xuất."""
        self.preview_base_pil = None
        self.preview_tk = None
        self.original_mesh = None
        self.stl_paths = []
        self.rot_x = self.rot_y = self.rot_z = 0.0
        try:
            self.canvas.config(width=CANVAS_SIZE, height=CANVAS_SIZE)
            self.canvas.delete("all")
            self.canvas.create_text(
                CANVAS_SIZE // 2,
                CANVAS_SIZE // 2,
                text="ĐANG LOAD STL...",
                fill="#dddddd",
                font=("Segoe UI", 18, "bold"),
            )
        except Exception:
            pass
        try:
            self.list_parts.delete(0, "end")
        except Exception:
            pass
        self.update_idletasks()
        gc.collect()

    # ---------------- Logging ----------------
    def log(self, msg: str):
        self.txt_log.insert("end", msg + "\n")
        self.txt_log.see("end")
        self.lbl_status.config(text=msg)
        self.update_idletasks()

    # ---------------- State / Settings ----------------
    def get_settings(self) -> RenderSettings:
        bg_mode = self.var_bg.get()
        return RenderSettings(
            image_size=int(self.var_png_size.get()),
            background_mode=bg_mode,
            background_color=BG_COLORS.get(bg_mode, "white"),
            transparent_background=(bg_mode == TRANSPARENT_BG_MODE),
            studio_background=(bg_mode in STUDIO_BG_MODES),
            model_color=MODEL_COLORS.get(self.var_color.get(), "#b8b6ad"),
            orthographic=bool(self.var_ortho.get()),
            zoom=float(self.var_zoom.get()),
            camera_height_ratio=float(self.var_height.get()),
            smooth=bool(self.var_smooth.get()),
            supersample=max(1, min(3, int(self.var_supersample.get()))),
            sharpen=bool(self.var_sharpen.get()),
        )

    def get_transformed_mesh(self):
        if self.original_mesh is None:
            return None
        return rotate_mesh(self.original_mesh, self.rot_x, self.rot_y, self.rot_z)

    def base_name(self) -> str:
        if not self.stl_paths:
            return "model"
        if len(self.stl_paths) == 1:
            return safe_filename(Path(self.stl_paths[0]).stem)
        parent_name = Path(self.stl_paths[0]).parent.name.strip() or "multi_parts"
        return safe_filename(parent_name + "_parts")

    # ---------------- Model loading ----------------
    def open_one_stl(self):
        if self.is_busy:
            messagebox.showwarning("Đang xử lý", "Hãy đợi tác vụ hiện tại hoàn thành rồi mở model mới.")
            return
        path = filedialog.askopenfilename(title="Chọn 1 file STL", filetypes=[("STL files", "*.stl")])
        if path:
            self.load_stl_paths([path])

    def open_stl_parts(self):
        if self.is_busy:
            messagebox.showwarning("Đang xử lý", "Hãy đợi tác vụ hiện tại hoàn thành rồi mở model mới.")
            return
        paths = filedialog.askopenfilenames(title="Chọn nhiều STL parts", filetypes=[("STL files", "*.stl")])
        if paths:
            self.load_stl_paths(list(paths))

    def load_stl_paths(self, paths: List[str]):
        if not self.begin_task("Đang đọc STL..."):
            return
        try:
            self.reset_runtime_before_new_model()
            self.pv = self.pv or import_pyvista()
            meshes = []
            good = []
            for path in paths:
                try:
                    mesh = load_single_mesh(self.pv, path)
                    meshes.append(mesh)
                    good.append(path)
                    self.log(f"OK: {Path(path).name}")
                except Exception as exc:
                    self.log(f"Bỏ qua file lỗi: {path} | {exc}")
                self.update_idletasks()
            if not meshes:
                raise RuntimeError("Không đọc được STL nào.")
            combined = combine_meshes_keep_coords(self.pv, meshes)
            try:
                combined = combined.compute_normals(
                    point_normals=True,
                    cell_normals=True,
                    auto_orient_normals=True,
                    consistent_normals=True,
                    inplace=False,
                )
            except Exception:
                pass
            self.original_mesh = combined
            self.stl_paths = good
            self.rot_x = self.rot_y = self.rot_z = 0.0
            self.update_rotation_label()
            self.list_parts.delete(0, "end")
            for p in good:
                self.list_parts.insert("end", p)
            if not self.var_output.get().strip():
                self.var_output.set(str(Path(good[0]).parent / "QuickShot_Output"))
            self.log(f"Đã load {len(good)} STL part. Giữ nguyên tọa độ gốc / vị trí tương đối.")
            self.update_preview_safe(force=True)
        except Exception as exc:
            tb = traceback.format_exc()
            write_crash_log(tb)
            messagebox.showerror("Lỗi load STL", f"{exc}\n\nĐã ghi crash_log.txt")
            self.log("Lỗi load STL.")
        finally:
            self.end_task("Load STL xong")

    def clear_scene(self):
        if self.is_busy:
            messagebox.showwarning("Đang xử lý", "Không clear scene khi đang render/xuất file.")
            return
        self.original_mesh = None
        self.stl_paths = []
        self.rot_x = self.rot_y = self.rot_z = 0.0
        self.preview_base_pil = None
        self.preview_tk = None
        self.canvas.delete("all")
        self.canvas.create_text(
            CANVAS_SIZE // 2,
            CANVAS_SIZE // 2,
            text="OPEN STL / OPEN STL PARTS",
            fill="#dddddd",
            font=("Segoe UI", 18, "bold"),
        )
        self.list_parts.delete(0, "end")
        self.update_rotation_label()
        try:
            self.canvas.config(width=CANVAS_SIZE, height=CANVAS_SIZE)
            gc.collect()
        except Exception:
            pass
        self.log("Đã clear scene.")

    # ---------------- Rotation ----------------
    def rotate_model(self, x=0.0, y=0.0, z=0.0):
        if self.is_busy:
            return
        if self.original_mesh is None:
            return
        self.rot_x += float(x)
        self.rot_y += float(y)
        self.rot_z += float(z)
        self.update_rotation_label()
        self.update_preview_safe()

    def reset_rotation(self):
        if self.is_busy:
            return
        self.rot_x = self.rot_y = self.rot_z = 0.0
        self.update_rotation_label()
        self.update_preview_safe()
        self.log("Đã reset góc model.")

    def update_rotation_label(self):
        self.lbl_rot.config(text=f"X={self.rot_x:.1f}°, Y={self.rot_y:.1f}°, Z={self.rot_z:.1f}°")

    # ---------------- Preview ----------------
    def update_preview_safe(self, force: bool = False):
        if self.original_mesh is None:
            return
        if self.is_busy and not force:
            return
        # Debounce nhẹ để khi chỉnh Spinbox/Combobox liên tục không render preview chồng.
        if not force:
            try:
                if self.preview_after_id is not None:
                    self.after_cancel(self.preview_after_id)
                self.preview_after_id = self.after(120, lambda: self.update_preview_safe(force=True))
            except Exception:
                self._update_preview_now()
            return
        self._update_preview_now()

    def _update_preview_now(self):
        if self.preview_pending or self.original_mesh is None:
            return
        self.preview_pending = True
        try:
            self.update_preview()
        except Exception as exc:
            tb = traceback.format_exc()
            write_crash_log(tb)
            self.log(f"Lỗi preview: {exc}")
        finally:
            self.preview_pending = False
            try:
                gc.collect()
            except Exception:
                pass

    def update_preview(self):
        self.log("Đang cập nhật preview...")
        self.pv = self.pv or import_pyvista()
        mesh = self.get_transformed_mesh()
        if mesh is None:
            return
        settings = self.get_settings()
        img = render_mesh_high_quality(self.pv, mesh, settings, angle_deg=0, final_size=CANVAS_SIZE, preview=True)
        self.preview_base_pil = img
        self.redraw_canvas()
        self.update_idletasks()
        self.log("Preview OK.")

    def redraw_canvas(self):
        try:
            self.canvas.config(width=CANVAS_SIZE, height=CANVAS_SIZE)
        except Exception:
            pass
        self.canvas.delete("all")
        if self.preview_base_pil is not None:
            self.preview_tk = ImageTk.PhotoImage(self.preview_base_pil.resize((CANVAS_SIZE, CANVAS_SIZE), Image.Resampling.LANCZOS))
            self.canvas.create_image(0, 0, image=self.preview_tk, anchor="nw", tags=("base",))
        else:
            self.canvas.create_rectangle(0, 0, CANVAS_SIZE, CANVAS_SIZE, fill="#202020", outline="")
        self.draw_logo(self.logo1)
        self.draw_logo(self.logo2)

    def logo_display_size(self, logo: LogoState, canvas_size: int = CANVAS_SIZE) -> Tuple[int, int]:
        if logo.pil is None:
            return 0, 0
        w = max(4, int(canvas_size * float(logo.scale_percent) / 100.0))
        h = max(4, int(logo.pil.height * w / max(1, logo.pil.width)))
        return w, h

    def sync_logo_vars(self, logo: LogoState):
        if logo.index not in self.logo_vars:
            return
        self._updating_logo_vars = True
        try:
            vars_ = self.logo_vars[logo.index]
            vars_["x"].set(int(round(logo.norm_x * 100)))
            vars_["y"].set(int(round(logo.norm_y * 100)))
            vars_["scale"].set(int(round(logo.scale_percent)))
            vars_["opacity"].set(int(round(logo.opacity_percent)))
        finally:
            self._updating_logo_vars = False

    def prepare_logo_image(self, logo_img: Image.Image, target_w: int, opacity: float = 1.0, sharpen: bool = True) -> Image.Image:
        """Resize logo từ file gốc, giữ alpha và tăng nét chữ/logo để không bị mềm."""
        target_w = max(4, int(target_w))
        src = logo_img.convert("RGBA")
        target_h = max(4, int(src.height * target_w / max(1, src.width)))
        # LANCZOS cho thu nhỏ/phóng to nhẹ; sau đó sharpen để logo chữ đỡ nhòe.
        im = src.resize((target_w, target_h), Image.Resampling.LANCZOS)
        if sharpen:
            alpha = im.getchannel("A")
            rgb = im.convert("RGB").filter(ImageFilter.UnsharpMask(radius=0.45, percent=170, threshold=1))
            im = rgb.convert("RGBA")
            im.putalpha(alpha)
        opacity = max(0.0, min(1.0, float(opacity)))
        if opacity < 0.999:
            alpha = im.getchannel("A")
            alpha = alpha.point(lambda p: int(p * opacity))
            im.putalpha(alpha)
        return im

    def draw_logo(self, logo: LogoState):
        if not logo.enabled or logo.pil is None:
            logo.canvas_item = None
            return
        try:
            w, h = self.logo_display_size(logo, CANVAS_SIZE)
            im = self.prepare_logo_image(logo.pil, w, float(logo.opacity_percent) / 100.0, sharpen=True)
            logo.tk_img = ImageTk.PhotoImage(im)
            x = int(logo.norm_x * CANVAS_SIZE)
            y = int(logo.norm_y * CANVAS_SIZE)
            x = max(0, min(x, CANVAS_SIZE - w))
            y = max(0, min(y, CANVAS_SIZE - h))
            logo.norm_x = x / CANVAS_SIZE
            logo.norm_y = y / CANVAS_SIZE
            self.sync_logo_vars(logo)
            logo.canvas_item = self.canvas.create_image(
                x,
                y,
                image=logo.tk_img,
                anchor="nw",
                tags=("logo", f"logo{logo.index}"),
            )
            # Khung nét đứt để dễ căn, không xuất ra file.
            outline = "#00aaff" if self.selected_logo is logo else "#5ed6ff"
            self.canvas.create_rectangle(x, y, x + w, y + h, outline=outline, dash=(4, 3), tags=("logo", f"logo{logo.index}", "logo_box"))
        except Exception as exc:
            self.log(f"Không vẽ được logo {logo.index}: {exc}")

    def find_logo_at(self, x: int, y: int) -> Optional[LogoState]:
        # Duyệt logo 2 trước để logo nằm trên được chọn trước.
        for logo in (self.logo2, self.logo1):
            if not logo.enabled or logo.pil is None:
                continue
            w, h = self.logo_display_size(logo, CANVAS_SIZE)
            lx = int(logo.norm_x * CANVAS_SIZE)
            ly = int(logo.norm_y * CANVAS_SIZE)
            if lx <= x <= lx + w and ly <= y <= ly + h:
                return logo
        return None

    # ---------------- Logo controls ----------------
    def choose_logo(self, logo: LogoState):
        path = filedialog.askopenfilename(
            title=f"Chọn Logo {logo.index}",
            filetypes=[("Ảnh logo", "*.png *.jpg *.jpeg *.webp"), ("PNG", "*.png"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            im = Image.open(path).convert("RGBA")
            logo.path = path
            logo.pil = im
            logo.enabled = True
            self.selected_logo = logo
            vars_ = self.logo_vars[logo.index]
            vars_["enabled"].set(True)
            logo.scale_percent = float(vars_["scale"].get())
            logo.opacity_percent = float(vars_["opacity"].get())
            logo.norm_x = max(0.0, min(1.0, float(vars_["x"].get()) / 100.0))
            logo.norm_y = max(0.0, min(1.0, float(vars_["y"].get()) / 100.0))
            self.sync_logo_vars(logo)
            self.redraw_canvas()
            self.log(f"Đã nạp Logo {logo.index}: {path}")
        except Exception as exc:
            messagebox.showerror("Lỗi logo", str(exc))

    def clear_logo(self, logo: LogoState):
        logo.clear()
        if self.selected_logo is logo:
            self.selected_logo = None
        self.logo_vars[logo.index]["enabled"].set(False)
        self.sync_logo_vars(logo)
        self.redraw_canvas()
        self.log(f"Đã xóa Logo {logo.index}.")

    def toggle_logo(self, logo: LogoState):
        logo.enabled = bool(self.logo_vars[logo.index]["enabled"].get()) and logo.pil is not None
        self.redraw_canvas()

    def update_logo_settings(self, logo: LogoState):
        if self._updating_logo_vars:
            return
        vars_ = self.logo_vars[logo.index]
        try:
            logo.scale_percent = max(2.0, min(80.0, float(vars_["scale"].get())))
            logo.opacity_percent = max(5.0, min(100.0, float(vars_["opacity"].get())))
            logo.norm_x = max(0.0, min(1.0, float(vars_["x"].get()) / 100.0))
            logo.norm_y = max(0.0, min(1.0, float(vars_["y"].get()) / 100.0))
        except Exception:
            pass
        self.selected_logo = logo
        self.redraw_canvas()

    def nudge_logo(self, logo: LogoState, dx: float, dy: float):
        logo.norm_x = max(0.0, min(1.0, logo.norm_x + float(dx)))
        logo.norm_y = max(0.0, min(1.0, logo.norm_y + float(dy)))
        self.selected_logo = logo
        self.sync_logo_vars(logo)
        self.redraw_canvas()

    def reset_logo_pos(self, logo: LogoState):
        logo.norm_x = 0.76 if logo.index == 1 else 0.04
        logo.norm_y = 0.84
        self.selected_logo = logo
        self.sync_logo_vars(logo)
        self.redraw_canvas()

    def on_logo_press(self, event):
        logo = self.find_logo_at(int(event.x), int(event.y))
        if not logo:
            self.drag_logo = None
            return
        self.drag_logo = logo
        self.selected_logo = logo
        x = int(logo.norm_x * CANVAS_SIZE)
        y = int(logo.norm_y * CANVAS_SIZE)
        self.drag_offset = (event.x - x, event.y - y)
        self.redraw_canvas()

    def on_logo_drag(self, event):
        logo = self.drag_logo
        if not logo:
            return
        w, h = self.logo_display_size(logo, CANVAS_SIZE)
        x = event.x - self.drag_offset[0]
        y = event.y - self.drag_offset[1]
        x = max(0, min(x, CANVAS_SIZE - w))
        y = max(0, min(y, CANVAS_SIZE - h))
        logo.norm_x = x / CANVAS_SIZE
        logo.norm_y = y / CANVAS_SIZE
        self.sync_logo_vars(logo)
        self.redraw_canvas()

    def on_logo_release(self, _event):
        if self.drag_logo:
            self.sync_logo_vars(self.drag_logo)
        self.drag_logo = None

    # ---------------- Export ----------------
    def choose_output_dir(self):
        path = filedialog.askdirectory(title="Chọn thư mục xuất")
        if path:
            self.var_output.set(path)

    def require_mesh_and_output(self) -> Optional[str]:
        if self.original_mesh is None or not self.stl_paths:
            messagebox.showwarning("Thiếu STL", "Hãy load STL trước.")
            return None
        out = self.var_output.get().strip()
        if not out:
            messagebox.showwarning("Thiếu thư mục xuất", "Hãy chọn thư mục xuất.")
            return None
        ensure_dir(out)
        return out

    def logo_overlay_data(self) -> List[Dict[str, Any]]:
        data = []
        for logo in (self.logo1, self.logo2):
            if logo.enabled and logo.pil is not None:
                data.append(
                    {
                        "pil": logo.pil,
                        "x_norm": float(logo.norm_x),
                        "y_norm": float(logo.norm_y),
                        "scale_percent": float(logo.scale_percent),
                        "opacity": float(logo.opacity_percent) / 100.0,
                    }
                )
        return data

    def apply_logos_to_image(self, image: Image.Image) -> Image.Image:
        image = image.convert("RGBA")
        w, h = image.size
        for item in self.logo_overlay_data():
            try:
                logo = item["pil"]
                target_w = max(4, int(w * item["scale_percent"] / 100.0))
                overlay = self.prepare_logo_image(logo, target_w, item["opacity"], sharpen=True)
                target_h = overlay.height
                x = int(item["x_norm"] * w)
                y = int(item["y_norm"] * h)
                x = max(0, min(x, max(0, w - target_w)))
                y = max(0, min(y, max(0, h - target_h)))
                image.alpha_composite(overlay, dest=(x, y))
            except Exception as exc:
                self.log(f"Không chèn được logo: {exc}")
        return image

    def render_output_frame(self, angle: float, size: int, settings: RenderSettings) -> Image.Image:
        self.pv = self.pv or import_pyvista()
        mesh = self.get_transformed_mesh()
        if mesh is None:
            raise RuntimeError("Chưa có mesh.")
        img = render_mesh_high_quality(self.pv, mesh, settings, angle_deg=angle, final_size=size, preview=False)
        return self.apply_logos_to_image(img)

    def export_png_front(self):
        self.export_png_views("1 PNG Front", [FRONT_ANGLE], [FRONT_NAME])

    def export_png_4(self):
        self.export_png_views("4 PNG Front/Back/Left/Right", VIEW4_ANGLES, VIEW4_NAMES)

    def export_png_views(self, title: str, angles: List[float], names: List[str]):
        if not self.begin_task(f"Bắt đầu xuất {title}..."):
            return
        out = self.require_mesh_and_output()
        if not out:
            self.end_task("Sẵn sàng")
            return
        try:
            settings = self.get_settings()
            size = int(settings.image_size)
            base = self.base_name()
            total = len(angles)
            for i, (ang, name) in enumerate(zip(angles, names), start=1):
                self.log(f"Render PNG {i}/{total}: {name}")
                img = self.render_output_frame(ang, size, settings)
                file_path = Path(out) / f"{base}_{i:02d}_{name}.png"
                img.save(file_path)
                self.log(f"Đã lưu: {file_path}")
                del img
                gc.collect()
                self.update_idletasks()
            self.log(f"Hoàn thành xuất {title}.")
            messagebox.showinfo("Xong", f"Đã xuất {title}.")
        except Exception as exc:
            tb = traceback.format_exc()
            write_crash_log(tb)
            messagebox.showerror("Lỗi xuất PNG", f"{exc}\n\nĐã ghi crash_log.txt")
        finally:
            self.end_task("Xuất ảnh xong")

    def export_png_8(self):
        self.export_png_views("8 PNG", VIEW_ANGLES, VIEW_NAMES)

    def export_gif(self):
        if not self.begin_task("Bắt đầu xuất GIF..."):
            return
        out = self.require_mesh_and_output()
        if not out:
            self.end_task("Sẵn sàng")
            return
        try:
            settings = self.get_settings()
            frames_count = int(self.var_gif_frames.get())
            fps = int(self.var_gif_fps.get())
            limit_mb = float(self.var_gif_limit.get())
            base = self.base_name()
            gif_path = Path(out) / f"{base}_turntable_720.gif"
            frames: List[Image.Image] = []
            self.log(f"Bắt đầu render GIF 720x720: {frames_count} frame...")
            angles = turntable_angles(frames_count, eased=bool(self.var_ease_rotate.get()))
            if settings.transparent_background:
                self.log("GIF không giữ alpha mượt như PNG, sẽ tự trải nền trắng khi nén GIF.")
            for i, angle in enumerate(angles):
                self.log(f"GIF frame {i + 1}/{frames_count}")
                img = self.render_output_frame(angle, GIF_SIZE, settings)
                if settings.transparent_background:
                    img = flatten_rgba(img, bg=(255, 255, 255)).convert("RGBA")
                frames.append(img)
                self.update_idletasks()
            final_path, mb, note = self.save_gif_under_limit(frames, gif_path, fps, limit_mb)
            self.log(f"Hoàn thành GIF: {final_path} | {mb:.2f} MB | {note}")
            if mb <= limit_mb:
                messagebox.showinfo("Xong", f"Đã xuất GIF: {mb:.2f} MB")
            else:
                messagebox.showwarning("GIF còn vượt giới hạn", f"GIF đã xuất nhưng còn {mb:.2f} MB. Hãy giảm Frame xuống 16 hoặc FPS xuống 10.")
            del frames
        except Exception as exc:
            tb = traceback.format_exc()
            write_crash_log(tb)
            messagebox.showerror("Lỗi xuất GIF", f"{exc}\n\nĐã ghi crash_log.txt")
        finally:
            self.end_task("Xuất GIF xong")

    def save_gif_under_limit(self, frames: List[Image.Image], path: Path, fps: int, target_mb: float):
        duration = max(20, int(1000 / max(1, fps)))
        limit_bytes = int(target_mb * 1024 * 1024)
        # Ưu tiên nhiều màu trước để logo không bị bệt/nhòe màu. Nếu vượt MB mới giảm dần.
        attempts = [
            (256, 1, "256 màu, logo rõ nhất"),
            (224, 1, "224 màu, đủ frame"),
            (192, 1, "192 màu, đủ frame"),
            (160, 1, "160 màu, đủ frame"),
            (128, 1, "128 màu, đủ frame"),
            (96, 1, "96 màu, đủ frame"),
            (64, 1, "64 màu, đủ frame"),
            (64, 2, "64 màu, bỏ cách 1 frame"),
            (48, 2, "48 màu, bỏ cách 1 frame"),
            (32, 2, "32 màu, bỏ cách 1 frame"),
            (32, 3, "32 màu, lấy mỗi 3 frame"),
        ]
        best_size = None
        best_note = ""
        for colors, step, note in attempts:
            use_frames = frames[::step]
            if len(use_frames) < 2:
                use_frames = frames[:2]
            q_frames = []
            for f in use_frames:
                rgb = f.convert("RGB")
                try:
                    q = rgb.quantize(colors=colors, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
                except Exception:
                    q = rgb.quantize(colors=colors, dither=Image.Dither.NONE)
                q_frames.append(q)
            q_frames[0].save(
                path,
                save_all=True,
                append_images=q_frames[1:],
                optimize=True,
                loop=0,
                duration=duration * step,
                disposal=2,
            )
            size_bytes = path.stat().st_size
            size_mb = size_bytes / (1024 * 1024)
            self.log(f"Thử GIF {note}: {size_mb:.2f} MB")
            if best_size is None or size_bytes < best_size:
                best_size = size_bytes
                best_note = note
            del q_frames
            gc.collect()
            if size_bytes <= limit_bytes:
                return str(path), size_mb, note
        return str(path), (best_size or path.stat().st_size) / (1024 * 1024), best_note

    def export_mp4(self):
        if not self.begin_task("Bắt đầu xuất MP4..."):
            return
        out = self.require_mesh_and_output()
        if not out:
            self.end_task("Sẵn sàng")
            return
        try:
            try:
                import imageio.v2 as imageio
                import numpy as np
            except Exception as exc:
                raise RuntimeError("Thiếu imageio/numpy/imageio-ffmpeg. Hãy chạy INSTALL_LIBS.bat") from exc
            settings = self.get_settings()
            fps = int(self.var_mp4_fps.get())
            seconds = int(self.var_mp4_seconds.get())
            frame_count = fps * seconds
            base = self.base_name()
            mp4_path = Path(out) / f"{base}_turntable_720.mp4"
            self.log(f"Bắt đầu xuất MP4: {frame_count} frame...")
            writer = imageio.get_writer(str(mp4_path), fps=fps, codec="libx264", quality=8, macro_block_size=1)
            try:
                angles = turntable_angles(frame_count, eased=bool(self.var_ease_rotate.get()))
                if settings.transparent_background:
                    self.log("MP4 không hỗ trợ alpha trong suốt, sẽ tự trải nền trắng.")
                for i, angle in enumerate(angles):
                    if i % max(1, fps // 2) == 0:
                        self.log(f"MP4 frame {i + 1}/{frame_count}")
                    img = self.render_output_frame(angle, GIF_SIZE, settings)
                    if settings.transparent_background:
                        img = flatten_rgba(img, bg=(255, 255, 255))
                    else:
                        img = img.convert("RGB")
                    writer.append_data(np.asarray(img))
                    del img
                    self.update_idletasks()
            finally:
                writer.close()
            self.log(f"Hoàn thành MP4: {mp4_path}")
            messagebox.showinfo("Xong", "Đã xuất MP4.")
        except Exception as exc:
            tb = traceback.format_exc()
            write_crash_log(tb)
            messagebox.showerror("Lỗi xuất MP4", f"{exc}\n\nĐã ghi crash_log.txt")
        finally:
            self.end_task("Xuất MP4 xong")

    def export_png_gif(self):
        self.export_png_8()
        self.export_gif()


def main():
    try:
        app = STLQuickShotApp()
        app.mainloop()
    except Exception:
        tb = traceback.format_exc()
        write_crash_log(tb)
        print(tb)
        try:
            messagebox.showerror("STL QuickShot lỗi", f"App bị lỗi. Đã ghi crash_log.txt\n\n{tb}")
        except Exception:
            pass
        raise


if __name__ == "__main__":
    main()
