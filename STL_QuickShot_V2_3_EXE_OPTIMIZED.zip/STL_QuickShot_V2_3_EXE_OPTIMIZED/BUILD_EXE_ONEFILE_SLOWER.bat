@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ==================================================
echo BUILD EXE ONEFILE - GON NHUNG MO CHAM HON
echo Neu uu tien muot/on dinh, dung BUILD_EXE_ONEDIR_FAST.bat.
echo ==================================================

if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller

pyinstaller ^
  --noconfirm ^
  --clean ^
  --noconsole ^
  --onefile ^
  --name STL_QuickShot_V2_3_OPTIMIZED_ONEFILE ^
  --collect-all pyvista ^
  --collect-all vtk ^
  --collect-all PIL ^
  --collect-all imageio_ffmpeg ^
  STL_QuickShot_V2_3_EXE_OPTIMIZED.py

echo.
echo EXE nam trong:
echo dist\STL_QuickShot_V2_3_OPTIMIZED_ONEFILE.exe
pause
