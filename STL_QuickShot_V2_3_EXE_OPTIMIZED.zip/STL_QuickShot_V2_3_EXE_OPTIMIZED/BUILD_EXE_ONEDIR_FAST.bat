@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ==================================================
echo BUILD EXE ONEDIR - KHUYEN DUNG
echo Mo nhanh hon ONEFILE va on dinh hon voi VTK/PyVista.
echo ==================================================

if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller

pyinstaller ^
  --noconfirm ^
  --clean ^
  --noconsole ^
  --onedir ^
  --name STL_QuickShot_V2_3_OPTIMIZED ^
  --collect-all pyvista ^
  --collect-all vtk ^
  --collect-all PIL ^
  --collect-all imageio_ffmpeg ^
  STL_QuickShot_V2_3_EXE_OPTIMIZED.py

echo.
echo EXE nam trong:
echo dist\STL_QuickShot_V2_3_OPTIMIZED\STL_QuickShot_V2_3_OPTIMIZED.exe
pause
