@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ==================================================
echo STL QuickShot V2.3 EXE OPTIMIZED - RUN PYTHON
echo ==================================================

if not exist ".venv\Scripts\python.exe" (
    echo Tao moi truong Python...
    py -3 -m venv .venv
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python STL_QuickShot_V2_3_EXE_OPTIMIZED.py
pause
