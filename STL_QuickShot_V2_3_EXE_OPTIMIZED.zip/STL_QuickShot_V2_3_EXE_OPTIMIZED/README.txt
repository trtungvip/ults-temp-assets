STL QuickShot V2.3 EXE OPTIMIZED
=================================

Phien ban nay duoc toi uu tu nhanh V2.3 gui kem.

Them moi:
1. Nut XUAT 1 PNG FRONT.
2. Nut XUAT 4 PNG FRONT / BACK / LEFT / RIGHT.
3. Giu lai XUAT 8 PNG, GIF 720x720 < 10MB, MP4.
4. Giam loi vang/treo sau khi ket thuc tac vu va mo model moi.
5. Co thanh progress khi dang load/render.
6. Khoa nut Open/Clear/Export khi dang xu ly de tranh bam chong tac vu.
7. Bo self.update() trong vong render, dung update_idletasks() de tranh re-enter Tkinter.
8. Don bo nho sau render tung frame va truoc khi load model moi.
9. Co dinh Canvas 680x680 de han che loi bi keo dan cua so/preview.

Thong so mac dinh van theo anh ban gui:
- Nen: Studio toi vien
- Mau model: Xam dam
- PNG: 1600 px
- Zoom: 1.18
- Do cao camera: 0.28
- Orthographic: bat
- Smooth shading: bat
- Render sac net: x3
- Tang net sau render: bat
- GIF: 48 frame, 12 FPS, 10 MB
- MP4: 5 giay, 24 FPS

Cach chay bang Python:
- Bam RUN_STL_QUICKSHOT_V2_3_OPTIMIZED.bat

Dong goi EXE:
- Khuyen dung BUILD_EXE_ONEDIR_FAST.bat
- ONEFILE co san nhung mo cham hon vi phai giai nen VTK/PyVista moi lan chay.

Goi y neu may yeu:
- Render sac net x2 thay vi x3.
- GIF 24 hoac 36 frame thay vi 48 frame.
